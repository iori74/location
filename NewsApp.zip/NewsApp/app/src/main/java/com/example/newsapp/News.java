package com.example.newsapp;

public class News {
    private final String mTitle;
    private final String mSectionName;
    private final String mUrl;
    private final String mAuthor;

    public News(String title, String sectionName, String url, String author) {
        mTitle = title;
        mSectionName = sectionName;
        mUrl = url;
        mAuthor = author;
    }

    public String getTitle() {
        return mTitle;
    }

    public String getSectionName() {
        return mSectionName;
    }

    public String getUrl() {
        return mUrl;
    }

    public String getAuthor() {
        return mAuthor;
    }
}
