package com.example.newsapp;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public final class QueryNews {

    private static final String NEWS_APP_JSON =
    "https://content.guardianapis.com/search?q=debate%20AND%20economy&tag=politics/politics&from-date=2014-01-01&api-key=test";

    private  QueryNews(){
    }

    public static ArrayList<News> extractNews() {

        // Create an empty ArrayList that we can start adding earthquakes to
        ArrayList<News> news = new ArrayList<>();

        // Try to parse the SAMPLE_JSON_RESPONSE. If there's a problem with the way the JSON
        // is formatted, a JSONException exception object will be thrown.
        // Catch the exception so the app doesn't crash, and print the error message to the logs.
        try {

            // Create a JSONObject from the SAMPLE_JSON_RESPONSE string
            JSONObject newsJsonResponse = new JSONObject(NEWS_APP_JSON);

            // Extract the JSONArray associated with the key called "response",
            // which represents a list of features (or earthquakes).
            JSONObject newsObject = newsJsonResponse.getJSONObject("response");

            JSONArray newsArray = newsObject.getJSONArray("results");

            // For each earthquake in the earthquakeArray, create an {@link Earthquake} object
            for (int i = 0; i < newsArray.length(); i++) {

                // Get a single earthquake at position i within the list of earthquakes


                // For a given earthquake, extract the JSONObject associated with the
                // key called "properties", which represents a list of all properties
                // for that earthquake.
                JSONObject results = newsArray.getJSONObject(i);

                // Extract the value for the key called "mag"
                String title = results.getString("webTitle");

                // Extract the value for the key called "place"
                String sectionName = results.getString("sectionName");
                String url =  results.getString("webUrl");

                // Create a new {@link Earthquake} object with the magnitude, location, time,
                // and url from the JSON response.
              News newsStructure  = new News(title,sectionName,url);

                // Add the new {@link Earthquake} to the list of earthquakes.
               news.add(newsStructure);
            }

        } catch (JSONException e) {
            // If an error is thrown when executing any of the above statements in the "try" block,
            // catch the exception here, so the app doesn't crash. Print a log message
            // with the message from the exception.
            Log.e("QueryUtils", "Problem parsing the earthquake JSON results", e);
        }

        // Return the list of earthquakes
        return news;
    }


}
