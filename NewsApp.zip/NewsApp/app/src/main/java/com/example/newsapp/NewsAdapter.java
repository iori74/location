package com.example.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class NewsAdapter extends ArrayAdapter<News> {

    public NewsAdapter(Context context, ArrayList<News> news) {
        super(context, 0, news);
    }


    @Override
    public View getView(int position, View View, ViewGroup parent) {
        if (View == null) {
            View = LayoutInflater.from(getContext()).inflate(
                    R.layout.common_list, parent, false);
        }

        News positionNews = getItem(position);

        TextView titleNews = (TextView) View.findViewById(R.id.title);
        titleNews.setText(positionNews.getTitle());

        TextView sectionNews = (TextView) View.findViewById(R.id.section_name);
        sectionNews.setText(positionNews.getSectionName());

        TextView author = (TextView) View.findViewById(R.id.author);
        author.setText(positionNews.getAuthor());
        return View;
    }
}
